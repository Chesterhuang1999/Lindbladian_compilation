#!/usr/bin/env python3
"""Bounded delivery validation; may run detached if the SSH link is unstable."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import socket
import subprocess
import sys
import traceback
from agent_search import ROOT, Session, source_identity, write_json
from pilot import FAST


def main():
    stamp = datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ')
    output = ROOT/'validation'/('remote_'+stamp)
    output.mkdir(parents=True, exist_ok=False)
    status = {'run':str(output), 'host':socket.gethostname(), 'source_identity':source_identity(),
              'status':'running', 'steps':[]}
    status_path = ROOT/'validation/status.json'
    write_json(status_path,status)
    try:
        provenance=json.loads((ROOT/'source_manifest.json').read_text())
        audit=[{'source':entry['source'],
                'unchanged':hashlib.sha256(Path(entry['source']).read_bytes()).hexdigest()==entry['sha256']}
               for entry in provenance['sources']]
        write_json(output/'upstream_audit.json',audit)
        if not all(entry['unchanged'] for entry in audit):
            raise RuntimeError('Upstream source hash changed; investigate before claiming isolation')
        status['steps'].append({'step':'upstream_audit','unchanged_files':len(audit)})
        for name, command in [('tests',[sys.executable,'-m','unittest','-v','test_interfaces'])]:
            with (output/(name+'.log')).open('w') as log:
                result = subprocess.run(command,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,
                                        timeout=300,check=False)
            status['steps'].append({'step':name,'exit_code':result.returncode})
            write_json(status_path,status)
            if result.returncode:
                raise RuntimeError(f'{name} failed; inspect log')
        session=Session.create(output/'tfim8',n=8,wall_seconds=300,cpu_seconds=240,lowering_calls=2)
        rid=session.call('observe')['root_repr_id']
        bundle=session.call('search_placements',{'repr_id':rid,'config':FAST,
                    'limits':{'wall_seconds':120,'cpu_seconds':120}})
        if bundle['status']!='completed':
            raise RuntimeError(f'TFIM8 placement: {bundle}')
        evaluation=session.call('evaluate',{'repr_id':rid,'placement_bundle_id':bundle['placement_bundle_id'],
                       'limits':{'wall_seconds':120,'cpu_seconds':120}})
        if evaluation['status']!='completed':
            raise RuntimeError(f'TFIM8 evaluation: {evaluation}')
        summary=session.call('finish',{'reason':'delivery_smoke'})
        write_json(output/'tfim8_summary.json',summary)
        status['steps'].append({'step':'tfim8','result':summary})
        write_json(status_path,status)
        for name, mode, extra in [('diagnostic','diagnose',['--profiles','fast']),
                                  ('controllers','compare',['--profile','fast'])]:
            command=[sys.executable,'pilot.py',mode,'--output',str(output/name),'--n','2',
                     '--repeats','1','--candidates','3' if mode=='diagnose' else '2','--rounds','1',
                     '--wall','120','--cpu','90','--lowerings','3','--per-call','60']+extra
            with (output/(name+'.log')).open('w') as log:
                result=subprocess.run(command,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,
                                      timeout=660,check=False)
            status['steps'].append({'step':name,'exit_code':result.returncode})
            write_json(status_path,status)
            if result.returncode:
                raise RuntimeError(f'{name} failed; inspect log')
        result=subprocess.run([sys.executable,'analyze_results.py',str(output/'controllers')],
                              cwd=ROOT,check=True,capture_output=True,text=True)
        status['steps'].append({'step':'analysis','summary':json.loads(result.stdout)})
        status['status']='passed'
    except Exception:
        status.update(status='failed',error=traceback.format_exc())
    write_json(status_path,status)
    write_json(output/'status.json',status)
    manifest_path=ROOT/'implementation_manifest.json'
    if manifest_path.exists():
        manifest=json.loads(manifest_path.read_text())
        manifest['remote_validation']=status
        write_json(manifest_path,manifest)
    print(json.dumps(status,ensure_ascii=False,indent=2),flush=True)
    return 0 if status['status']=='passed' else 1


if __name__=='__main__':
    sys.exit(main())
