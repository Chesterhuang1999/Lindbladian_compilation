# Goal 1：ChannelIR 跨层联合搜索的可执行探索计划

版本：2026-09-17。状态：接口与试验控制器的隔离实现；正式研究实验尚未执行。

## 1. 本轮要回答的问题

在同一输入、固定编译后端和相同总预算下，联合选择 Kraus representation 与 Pauli placement，能否优于已启用 rewrite、Matrix-order 与通道树结构优化的分层路线？

分别检验两个命题：

1. **预测问题**：上层启发式评分与固定下游搜索预算下的完整电路成本是否存在稳定的排序反转、同分异质性或预算依赖？
2. **决策问题**：保留候选、利用下游反馈及再次分配搜索预算，能否把这些现象转化为更好的最终结果？

发现第一个现象不自动证明第二个命题。有限预算下未观察到收益，也不证明联合搜索不存在收益。Agent 可以通过本目录接口自主安排后续探索；本轮提供确定性控制器用于目标 1，不开展原 Goal 的目标 2“Agent 相对强非 Agent 控制器的增量贡献”，不调用任何模型 API。

## 2. 实际目录、源码来源与运行环境

远端：`huangqf@192.168.20.20`。

```text
/home/huangqf/Lindbladian_compilation/agent-search-explore/
  agent_search.py              持久化 JSON/Python 接口、预算、缓存、账本
  pilot.py                     诊断网格、5 个控制器及排序反转统计
  analyze_results.py           评估明细、质量随预算变化、基线配对 CSV
  test_interfaces.py           接口与小规模语义验收
  goal.md                      本计划
  source_manifest.json         原始来源路径与 SHA-256
  implementation_manifest.json 交付文件哈希与验证记录（交付时生成）
  src/channel_IR.py            复制版；增加真实 beam 剪枝轨迹 observer
  src/placement_search.py      复制版；增加搜索数值监控和 placement 合法性检查
  src/block_encoding_new_fixed.py 复制版；增加配置注入、placement 导出与精确重放
  src/search_contract.py       数值契约、输入构造、论文启发式
  src/search_worker.py         隔离计算、语义验证、完整通道 NAM lowering
  src/...                     复制的必要编译依赖
  originals/main/             远端旧主目录 Python 源码快照
  originals/deployed/         本次采用的远端部署版源码原件
  runs/                       后续实验输出，各运行独立目录
  validation/                 交付时实际验证日志与 smoke 结果
```

远端主项目 `/home/huangqf/Lindbladian_compilation` 的源码版本较旧，没有 `placement_search.py`。本轮以服务器上已经存在的部署版本为实际编译基础：

`/home/huangqf/tfim_tud_remote_20260910_1925/deployment_hrw_rewrite_20260911/src`。

与同服务器 TFIM 部署核对，主要编译脚本一致。本目录保留逐文件来源；原主目录和既有部署目录都不修改。本轮调用的是带零地址相位修正的 `block_encoding_new_fixed.py`，不是主目录旧后端。

解释器固定为：

```bash
cd /home/huangqf/Lindbladian_compilation/agent-search-explore
PY=/home/huangqf/miniconda3/envs/qiskit_simulate/bin/python
"$PY" -m unittest -v test_interfaces
```

已核对的环境为 Python 3.12.9、Qiskit 2.1.1、NumPy 2.4.2、psutil 5.9.0，并具备 qsppack、pyqsp、sympy。工作进程将数值库线程数固定为 1。各 session 固定源码及关键库版本的哈希；代码变更后旧 session 只作为历史证据，重新创建实验，不能继续沿用旧缓存。

## 3. 冻结数值契约

唯一主目标是

\[
C(A,\pi)=G_{\mathrm{NAM,full}}(A,\pi)/p(A),\qquad
p(A)=\tau/\Lambda(A).
\]

- `G` 是完整通道电路最后统一 lowering 到 `{rz,h,x,cx}`、Qiskit opt0 的总门数；reset 不计入。禁止以 SELECT 门数、内部估计门数或单个 Kraus 门数之和代替它。
- 输入参考态固定为 `rho_ref = I/2^n`；对于合并重复 Pauli 后的标准 Pauli 系数矩阵，`tau = Tr(E(rho_ref)) = sum(abs(A[j,l])**2)`。
- `Lambda = sum_j (sum_l abs(A[j,l]))**2`。因此 `C=G*Lambda/tau`；只有确认输入是 TP 时才使用 `C=G*Lambda`。Euler TFIM 输入在有限步长下不假设严格 TP。
- width 仅作为附加记录，不进入目标、controller 的筛选或并列决策，也不设独立的 Lambda 上限。后端沿用固定的地址宽度规则；本轮没有开放宽度搜索动作。
- 使用标准 Pauli 列、显式复系数和原 Kraus 行顺序。内置输入执行一次已有的全局相位消除；后续候选保留实际复系数，不在评估过程中隐式改写表示。
- 系数裁剪阈值 `1e-12`；候选相对根表示的 `A†A` 残差不超过 `1e-10` 的相对阈值。拒绝非法或过期结果，不允许它们更新 incumbent。
- 每个真实 SELECT 地址都检查 Pauli 及复相位重构。系统不超过 3 qubits 且完整电路不超过 18 qubits 时，额外逐输入基态验证完整成功分支。较大实例使用代数检查与已验收的组装器，不声称完成指数规模的完整电路数值验证。

论文的 `H_length` **已经含 Lambda**。接口使用 `paper_H_length_with_lambda_v1`，逐字实现当前论文公式的 `G_sp,nc`、`G_sp,tot`、`T_mc`；包括公式对少控制位的定义，不自行替换近似式。该评分偏向 non-Clifford 成本，是待检验的上层启发式，不是主指标，也不再另立第三种成本模型或再次乘 Lambda。

特别记录版本差异：本次复制的远端 `rewrite_search` 实际按 support 评分；它虽有 `gatecost_rewrite_search` 包装入口，却缺少被导入模块。因此 `current_layered` 必须标为“远端部署 support-beam 基线”，不能声称它就是论文 H_length 搜索。`proxy_layered` 是本目录新增的论文评分 beam 对照。

## 4. Agent 可调用接口及默认返回

调用有两种等价方式：

```python
from agent_search import Session
s = Session.create("runs/manual_tfim8", n=8, wall_seconds=1200,
                   cpu_seconds=600, lowering_calls=12)
root = s.call("observe")["root_repr_id"]
```

```bash
"$PY" agent_search.py init runs/manual_tfim8 --n 8 --wall-seconds 1200 --cpu-seconds 600 --lowering-calls 12
"$PY" agent_search.py call runs/manual_tfim8 observe
```

上述两种初始化方式任选一种；同名目录存在时拒绝覆盖。所有 ID 都必须来自真实返回，不能使用说明中的虚构 ID。

| 接口 | 主要参数 | 默认返回及用途 |
|---|---|---|
| `observe` | 可选 `repr_id, include_structure` | 活跃候选 ID、上层评分、已测 C/placement/seed/config 引用、incumbent ID、总预算；结构显式按需取 |
| `propose_rewrites` | `parent_repr_id, pair_selector, cursor, limits` | 未经 support/H 剪枝的候选 ID 与上层评分、下一页 cursor、此次实耗、event ID |
| `search_placements` | `repr_id, kraus_ids, base_bundle_id, config, seed_index, limits` | bundle ID、未完成的 Kraus ID、有效配置引用、终止原因、实耗 |
| `evaluate` | `repr_id, placement_bundle_id, limits` | evaluation ID、`expected_gate_count`、状态、实耗；只编译传入 placement，不再次搜索 |
| `update_frontier` | `activate, archive` | 实际激活/归档 ID、拒绝 ID、revision；不重复返回成本，归档不删除已知最优、工件或缓存 |
| `inspect_ledger` | 默认汇总；可选 `repr_id` 或 `detail=true` | 已用/剩余 wall、工具 CPU、lowering 尝试数、cache hit 数、revision、账本引用；明细按需 |
| `lookup_cache` | `operation, args` | 精确 hit/miss、结果引用、原始 event；查询不执行搜索 |
| `finish` | 可选 `reason` | 最佳合法 evaluation ID/C、停止原因、总消耗；此后仅允许读取 |

另提供 `run_legacy_rewrite(repr_id, beam_width, max_steps, trace, limits)` 用于真实部署基线和剪枝诊断。它返回最佳表示和终止摘要；只有 `trace=true` 时额外生成完整剪枝轨迹。诊断开启该开关，正式基线关闭它，避免让额外诊断开销削弱正式基线。轨迹区分不相交 pair 跳过、support 增加、pair 过滤、visited 去重、beam 容量淘汰等；`pair_filter_rejected` 尚未进一步区分 neutral potential 与 neutral 数量上限，不得据此编造更细原因。

最小完整调用示例：

```python
p = s.call("propose_rewrites", {
    "parent_repr_id": root, "pair_selector": "all",
    "limits": {"max_pairs": 4, "max_unitaries": 128, "page_size": 8,
               "wall_seconds": 60, "cpu_seconds": 60}})
r = p["candidates"][0]["repr_id"] if p.get("candidates") else root
s.call("update_frontier", {"activate": [r]})
b = s.call("search_placements", {
    "repr_id": r, "kraus_ids": "all", "config": {}, "seed_index": 0,
    "limits": {"wall_seconds": 120, "cpu_seconds": 120}})
if b["status"] == "completed":
    e = s.call("evaluate", {
        "repr_id": r, "placement_bundle_id": b["placement_bundle_id"],
        "limits": {"wall_seconds": 120, "cpu_seconds": 120}})
print(s.call("inspect_ledger"))
print(s.call("finish", {"reason": "manual_example_completed"}))
```

`config={}` 固定本次部署的默认小实例配置：beam/layer/exact 限制均为 16，mixed 初始保留 128、低权重候选 128、随机候选 256；其余值见每次返回的 `effective_config_ref`。随机种子由 `seed_index` 加固定偏移生成。`lookahead_depth` 只支持 0/1。每次 placement 调用是新一次搜索，不宣称续接之前的 beam；可用 `base_bundle_id` 仅重新搜索指定 Kraus，其余采用已有映射。

候选的工作上限 `max_pairs/max_unitaries` 与输出大小 `page_size` 分开；分页 cursor 绑定父表示及 pair 选择器。候选 ID 的精确内容哈希包含 Kraus 顺序和复相位，缓存绝不用通道 Gram 或忽略相位/行顺序的 visited key 代替。不同 seed/config/base bundle 不误命中；超时、失败结果不缓存为成功结果。

全量 `G,p,Lambda,tau,width`、原生电路 QPY、语义残差、分阶段耗时、求解器 layer 监控和真实变换存入工件；默认响应保持精简。`state.json` 保存索引与指标，`ledger.jsonl` 保存动作轨迹，`artifacts/event_*/request.json/result.json/worker.log` 保存计算证据。

## 5. 预算与异常规则

每个 session 同时设 wall、工具 CPU 与完整 lowering **尝试**次数上限，先达到任何计算预算上限就停止新增计算。wall 从 session 建立开始，包含调用间决策和等待；工具 CPU 包括工作进程及可观测子进程和可计量接口控制开销。外部 Agent 的模型服务 CPU 不属于此值，模型等待仍计入 wall。初始化公共输入成本作为共享前置工作，不算作某种搜索方法的独享收益。

工作进程隔离运行；约 20ms 轮询检查 wall/CPU，超限杀死进程组。轮询和进程回收可能产生小幅超额，按实耗记录，过期结果不接受。CPU 完成值结合工作进程自身 rusage；被杀进程的 CPU 是采样记录，不能宣称纳秒精度。lowering 调用在启动前预留，包含在进入最终 transpile 之前失败/超时的评估尝试。

缓存仅在单一 session 中有效，正式方法之间不共享免费缓存。首次计算收费，命中只计实际查询/接口开销。结束后的最佳结果不会因归档候选而消失。

外部强制终止 controller 时，`pending` 记录会阻止继续使用账本不完整的 session。保留该运行、检查是否仍有其工作进程，并创建新运行重做；本版不实现不可靠的崩溃后自动续算。不要删除失败实验。正常超时则可直接继续用剩余预算探索其他候选。

## 6. 分阶段运行与验收

### 阶段 A：工程验收和时间校准

先执行第 2 节的测试。要求接口测试全部通过，且完整成功分支残差小于 `1e-10`。验收覆盖原后端默认行为不变、指定 placement 不发生重搜、复相位、非 identity 零地址、填充地址、完整/不完整 bundle、分页等价性、缓存和超时计费。

仅用 TFIM-2 和一个预留校准输入确定单次编译是否落在 120s 内。若预算无法完成一次合法评估，先按记录统一调整所有方法预算，冻结后才开展正式比较。不能针对表现差的方法单独加时。

最小诊断 smoke：

```bash
"$PY" pilot.py diagnose --output runs/smoke_diagnostic_tfim2 --n 2 \
  --profiles fast --repeats 1 --candidates 3 --rounds 1 \
  --wall 240 --cpu 180 --lowerings 3 --per-call 60
```

最小策略 smoke（只验证运行链路，不作统计结论）：

```bash
"$PY" pilot.py compare --output runs/smoke_controllers_tfim2 --n 2 \
  --profile fast --repeats 1 --candidates 2 --rounds 1 \
  --wall 120 --cpu 90 --lowerings 3 --per-call 60
```

### 阶段 B：共同候选的诊断

初始实例：TFIM `n=2,4,8`、`dt=0.01`、`gamma=0.1`、开边界；内置 Euler 构造固定为 `H=-sum X_i-sum Z_i Z_(i+1)`、`L_i=sqrt(gamma)/2*(X_i-iY_i)`、`K0=I-i*dt*H-dt/2*sum L_i†L_i`、`Ki=sqrt(dt)*Li`。

每实例先收集根表示、真实 legacy rewrite 胜者，以及未剪枝枚举的共同候选，上限 8 个。对每个共同候选使用相同 fast/default placement 配置、相同 5 个 seed 和相同单调用上限，记录完整 grid。候选不足或某些格子超时必须报告，不用成功样本悄悄补齐失败格子。

```bash
"$PY" pilot.py diagnose --output runs/diagnostic_tfim8 --n 8 \
  --profiles fast default --repeats 5 --candidates 8 --rounds 3 \
  --wall 14400 --cpu 7200 --lowerings 80 --per-call 120
```

`diagnostic_records.json` 存每个候选/配置/seed 的评分、C 与实际 legacy 剪枝原因匹配；`pair_diagnostics.json` 输出配对成本比、启发式并列、反转比例。代码对至少 5 个有效配对、至少 80% 的 seed 同方向反转、中位相对差异至少 5% 标记 **stable_reversal_screen**；这是探索性筛选，不是独立检验的显著性结论。

分别分析：同一个 H 的成本离散；不同 H 的反转；fast/default 排序变化；只在单次 seed 出现的波动；真实剪枝轨迹中的候选是否被其他轮次重新保留。`legacy_trace_reasons=[]` 意味着没有匹配证据，不能解释为“曾被淘汰”。候选同时存在 keep/reject 记录时，要回到轨迹的 step 和 parent 解释，不能一概视为永久剪枝。

诊断消耗单列，不能将最优候选、好 seed 或配置作为阶段 C 的免费输入。

### 阶段 C：同预算策略比较

已实现的 5 个 controller：

| 方法 | 精确行为 |
|---|---|
| `current_layered` | 先测公共输入 incumbent；运行远端 support-beam rewrite（beam=8）；只在上层选出的表示上做多 seed 默认 placement 与完整评估，取已测最优 |
| `proxy_layered` | 相同原语上用论文 H_length 做最多 8 个状态的 beam；保留不增加 H 的候选；最终固定表示后做多 seed 下游搜索 |
| `alternating` | 从枚举流中的不同起点开始，上层提案和下游评估交替；按测得 C 接受改进，周期性回到根表示选择新起点，归档未接受的分支 |
| `nested` | 按根表示的固定枚举流逐个评估候选；使用相同下游配置和固定单调用上限；候选调度不依赖下游 C |
| `frontier` | 保留已生成候选，结合已测 C 选择下一扩展对象，周期性探索根表示；每三次决策重访最佳已测表示，将 beam/layer 参数加倍（上限 64），所有投入计费 |

这些是本轮可运行的有限搜索策略定义，不宣称穷尽全部联合搜索空间。特别是 nested 当前覆盖根表示邻域；比较结论必须注明该范围。论文评分 beam 的每个父状态最多取 `--candidates` 个枚举结果，并非完整连续 U(2) 搜索。

正式比较使用相同 fresh session、相同初始实例和公共动作库、同样的完整评估器。每种方法都支付根表示的首次评估。方法的运行顺序随 repeat 轮换，服务器负载异常另行标记。

建议预注册 3 档预算：

| 档位 | wall 上限 | 工具 CPU 上限 | 完整评估尝试上限 |
|---|---:|---:|---:|
| 小 | 120s | 60s | 4 |
| 中 | 360s | 180s | 12 |
| 大 | 1200s | 600s | 40 |

每个实例/预算/方法重复 5 次。每次最多 64 次 controller 决策，rewrite 最大步数设置 50；若先达 controller 停止条件，报告实际使用预算，不把剩余预算视为已消耗。

```bash
"$PY" pilot.py compare --output runs/compare_tfim8_medium --n 8 \
  --profile default --repeats 5 --candidates 64 --rounds 50 \
  --wall 360 --cpu 180 --lowerings 12 --per-call 120
```

分别替换 `--n`、输出目录和三档预算执行其余 TFIM 配置。阶段 B 不参与调参的留出实例为 `mixed_pauli n=3/4, input-seed=11/23`（TP Pauli-mixture 经随机 Kraus 酉混合）和 `TFIM-8 dt=0.02`。它们由同一 `pilot.py --family mixed_pauli --input-seed ...` 或 `--dt 0.02` 命令运行。`pauli_mixture` 用作结构简单、预期联合收益较小的负对照。

### 阶段 D：机制对照与复核

只对阶段 C 出现可复现改善的实例执行下列独立 fresh-session 对照，预算和 seed 数不变：

```bash
"$PY" pilot.py compare --output runs/ablation_tfim8_no_feedback --n 8 \
  --methods frontier --no-feedback --repeats 5 --candidates 64 --rounds 50 \
  --wall 360 --cpu 180 --lowerings 12 --per-call 120
"$PY" pilot.py compare --output runs/ablation_tfim8_no_adaptive --n 8 \
  --methods frontier --no-adaptive --repeats 5 --candidates 64 --rounds 50 \
  --wall 360 --cpu 180 --lowerings 12 --per-call 120
```

`--no-feedback` 将 **调度依据** 从已测 C 改为 H；最终仍报告所有合法已测结果的最低 C，这是所有方法共有的评价规则。`--no-adaptive` 去掉定期重访和加大 beam/layer 的分配策略，固定 placement 配置。它同时影响重访与计算投入，不能单独归因为其中一个因素。

根据完整轨迹核查：收益是否只是多起点；是否利用了过去没有评估的表示；是否在相同表示上仅靠更多下游预算获益；是否存在按真实 trace 证实的早期剪枝损失。候选之间比较必须对齐 seed、配置和预算，不能以一个候选花更多时间后的结果说明表示本身更好。

## 7. 分析产物与停止条件

所有正式 run 输出不可覆盖；目录名应包含实例、预算、方法、日期或序号。每个 run 保留 session state、账本、候选变换、placement、完整 QPY、验证状态与 runtime/source hash。

最终报告至少包含：

1. 候选诊断表：H、support、Lambda、tau、配置、seed、G、p、C、width、实际消耗、剪枝证据。
2. 配对结果表：每种方法相对于两个分层基线的 `C_method/C_baseline`、5 次结果、中位数、胜/平/负、失败/超时比例；不要先跨实例平均原始门数。
3. 从账本重建最佳 C 随实际 wall、工具 CPU、lowering 尝试数变化的曲线；使用两个轴分别报告，不混同工具预算和端到端预算。
4. 成本改善的机制案例和无收益案例；对留出实例保持方法参数不变。

运行后直接导出分析数据：

```bash
"$PY" analyze_results.py runs/compare_tfim8_medium
```

输出为该目录下 `analysis/evaluations.csv`、`anytime.csv`、`runs.csv`、`paired.csv`。配对仅在同一比较目录、同一 repeat 内完成，失败结果保留为 missing；不能把未完成配对当作平局。可从这些 CSV 绘制曲线并汇总中位数，报告中须保留原始 5 次结果。

排序反转的筛选和最终收益的检验分别报告；试验规模小，不用多个 seed 把一个实例伪装成多个独立实例。若筛选后挑选显著案例，需要新 seed/留出输入确认，并报告筛选范围。

具体停止规则：

- **单次运行**：预算耗尽、controller 决策上限、候选枚举/beam 无可推进状态或明确结束时停止；无合法结果则输出无结果状态，不以 0 成本代替。
- **工程停止**：发现 Gram/SELECT/完整成功分支语义失败、精确重放引入重搜、缓存跨 seed/config 误命中，立即停止正式比较，保留反例并修复重验。不能将非法低成本结果纳入排名。
- **资源停止**：本轮诊断与正式比较总工具 CPU 累计以 24 小时为第一阶段上限，按各独立账本求和；接近上限时只完成已启动运行，停止追加实例。该跨 session 总额是研究执行者的检查点，单个 session 的硬上限由接口执行。
- **研究阶段完成**：至少覆盖 TFIM-2/4/8、三档预算、5 次重复、两个分层基线和三个联合策略；若有稳定收益则完成机制对照及至少两个留出配置，否则完成负对照与失败原因分析，交付带适用范围的正/负结论。
- **暂不进入目标 2**：若无法获得足够多合法完整评估，或联合搜索本身在留出实例没有可复核收益，先说明原因；不能把模型参与包装成已有研究收益。

## 8. 本版边界与下一步

已实现本轮所需数值接口、持久化记录、固定后端精确重放、共同候选诊断、5 个试验控制器及两项调度对照。没有实现任意连续 Kraus 酉搜索、可恢复 placement beam、分布式多 writer、进程异常崩溃后自动续算、任意参考态成功概率，也没有对大电路做完整矩阵级验证。

内置 benchmark 为 TFIM 与 Pauli-mixture 两类；其他已有 Lindbladian 前端可以通过 Python `Session.create(..., representation=...)` 提交合并后的标准 Pauli 系数矩阵，但应先明确其输入构造与成功概率契约。不得把旧论文表中的输入直接当成本版 TFIM Euler 输入。

交付验证以 `validation/` 与 `implementation_manifest.json` 为准。测试通过只说明接口和检查链路可运行，不意味着“联合搜索优于分层搜索”已经被实验证明。
